#!/bin/bash


filenum=`ls -l | grep file | wc -l`

cnt=0

for fname in file*
do
	cnt=$(($cnt+1))
	numzero=$((${#filenum}-${#cnt}))
	if [ $numzero -eq 0 ]; then
		mv $fname ${cnt}
	else
		zero=""
		for ((i=1; i<=$numzero; i++))
		do
			zero=$zero"0"
		done
		mv $fname $zero${cnt}
	fi
done

