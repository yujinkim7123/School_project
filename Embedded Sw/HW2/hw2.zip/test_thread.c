#include<stdio.h>
#include<stdlib.h>
#include<unistd.h>
#include<pthread.h>


void* threadFunc(void *value){

   long long *a = (long long*)value;
   for (int i = 1; i <=333333330; i++){
    *a = *a + i;
  }
    return a;
}

void* threadFunc2(void *value){

   long long *a = (long long*)value;
   for (int i =333333330; i <=666666660; i++){
    *a = *a+i;
  }
    return a;
}

void* threadFunc3(void *value){

   long long *a = (long long*)value;
   for (int i = 666666660; i <=999999990; i++){
    *a = *a+i;
  }
    return a;
}



int main(int argc, char **argv){

pthread_t one , two, three;

long long x=0, y=0, z=0;



if(pthread_create(&one, NULL, &threadFunc, &x)!=0){
      
        return 1;
    }

if(pthread_create(&two, NULL, &threadFunc2, &y)!=0){
    return 1;
}

if(pthread_create(&three, NULL, &threadFunc3, &z)!=0){
    return 1;
}

void* result;
void* result2;
void* result3;

pthread_join(one, &result);
pthread_join(two, &result2);
pthread_join(three, &result3);

long long* res1 = (long long*) result;
long long* res2 = (long long*) result2;
long long* res3 = (long long*) result3;


printf("Value: %lld\n", *res1 + *res2 + *res3);

}
