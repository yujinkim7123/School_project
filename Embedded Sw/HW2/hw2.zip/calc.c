
#include <stdio.h>

float add(float a, float b)
{
    return a + b;
}

float sub(float a, float b)
{
    return a - b;
}

float mul(float a, float b)
{
    return a*b;
}

float div(float a, float b)
{
    return a/b;
}


int main(){

    float (*fp[4])(float, float);

    int choice;
    float num1, num2;
    float result;

    fp[0] = add;    
    fp[1] = sub;   
    fp[2] = mul;   
    fp[3] = div;   

       while(1){

    	printf("Enter your choice: 1 for sum, 2 for subtraction, 3 for mult, 4 for division, and 0 for exit: ");
    	scanf("%d", &choice);
    	
        if(choice==0){
    	     break;	
    	}
        printf("Enter the two numbers: "); 
    	scanf("%f %f", &num1, &num2); 

	result = fp[choice-1](num1, num2);    
        printf("%f\n", result);
        
}
   

    return 0;

}
