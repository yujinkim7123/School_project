#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>

int main(int argc, char **argv)
{
  long long a = 0;
  
  for (int i =1; i <=999999990; i++)
	a = a+ i;

printf("Value: %lld\n",a);

return 0;

}
