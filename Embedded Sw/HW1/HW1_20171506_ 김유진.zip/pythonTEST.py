#!/usr/bin/pythono

import sys
from time import sleep
PATH = "/sys/class/gpio/gpio3/"
SYSFS_DIR = "/sys/class/gpio/"
TEST_GPIO ="3"

def setTEST(filename, value, path=PATH):
	f=open(path + filename, "w")
	f.write(value)
	f.close()
	return

print("Starting the GPIO TEST Python Script!")

if len(sys.argv)!=2:
	print("There is an incorrect number of arguments")
	print(" usage is: pythonTEST.py command")
	print(" where command is one of setup, on, off, status, or close")
	sys.exit(2)

if sys.argv[1]=="setup":
	print("Setting up the TEST GPIO")
	setTEST(filename="export",value=TEST_GPIO, path=SYSFS_DIR)
	sleep(0.1)
	setTEST(filename="direction", value="out")

elif sys.argv[1]=="on":
	print("Turning the TEST on")
	setTEST(filename="value", value="1")

elif sys.argv[1]=="off":
	print("Turning the TEST off")
	setTEST(filename="value", value="0")

elif sys.argv[1]=="status":
	print("Getting the TEST state value")
	f = open(PATH + "value" , "r")
	print(f.read())
	f.close()

elif sys.argv[1]=="close":
	print("Closing down the TEST GPIO")
	setTEST(filename="unexport", value=TEST_GPIO, path=SYSFS_DIR)

else:
	print("Invalid command!")

print("End of Python script")


