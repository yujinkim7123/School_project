#include <iostream>

using namespace std;

void test_show()
{

cout << "20171506" << endl;

}
