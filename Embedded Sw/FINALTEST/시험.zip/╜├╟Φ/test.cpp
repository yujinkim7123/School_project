#include"test_lib.h"
using namespace std;

int main(){

test_show();

}
