import RPi.GPIO as GPIO
import dht11
import time
import sys
GPIO.setwarnings(True)
GPIO.setmode(GPIO.BCM)

instance = dht11.DHT11(pin=22)

sumtemp = 0
sumhumi = 0
count = 0

try:
    while True:
        result = instance.read()
        if result.is_valid():
            count = count + 1
            temp = (float)("%.1f" % result.temperature)
            sumtemp =  sumtemp + temp 
            humi = (float)("%.1f" % result.humidity)
            sumhumi = sumhumi + humi
            message = sumtemp/10, sumhumi/10
            if(count == 10):
                print(time.strftime('%c', time.localtime(time.time())))
                print (message)
                sumtemp = 0
                sumhumi = 0
                count = 0
            time.sleep(1)
except KeyboardInterrupt:
    print("Cleanup")
    GPIO.cleanup()
