#include <stdio.h>
#include <stdlib.h>
#include <string.h>

 float add(float a, float b)
{
    return a + b;
}

float sub(float a, float b)
{
    return a - b;
}

float mul(float a, float b)
{
    return a * b;
}

float div1(float a, float b)
{
    return a / b;
}



int main(){

    float (*fp[4])(float, float);

    int calc;
    float num1, num2;
    float result;

    fp[0] = add;    
    fp[1] = sub;   
    fp[2] = mul;   
    fp[3] = div1;   

    while(1){

    printf("Enter your choice: 1 for sum, 2 for subtraction, 3 for mult, 4 for division, and 0 for exit:");
    scanf("%d", &calc);
    printf("Enter the two numbers:"); 
    scanf("%f %f ", &num1, &num2); 

    if(calc==0){
        break;
    }

    else{
    result = fp[calc-1](num1, num2);    
      printf("%f", result);
     }
    }

    return 0;

}