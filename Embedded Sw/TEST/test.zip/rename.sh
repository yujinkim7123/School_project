#! bin/bash


count = sudo  find . | grep file | wc -l 


nulls=$(echo "$count" | sed "s/1//g")    # delete 1's


for file in /Test/file*
    mv file 
