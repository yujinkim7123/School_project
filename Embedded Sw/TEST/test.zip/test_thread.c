#include <stdio.h>
#include<stdlib.h>
#include<unistd.h>
#include <pthread.h>


void *threadFunction(void *value){

   long long *a = (long long*)value;
   for (int i =1; i <=999999990; i++){
    a =a+i;
  }
    return a;
}



int main(int argc, char **argv){
long long a = 0;
pthread_t thread[2];

if(pthread_create(&thread[0], NULL, &threadFunction, &a)!=0){
      
        return 1;
    }

if(pthread_create(&thread[1], NULL, &threadFunction, &a)!=0){
    return 1;
}


pthread_join(thread[0]);
pthread_join(thread[1]);

printf("Value: %lld\n", a);

}